from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table
from tqdm import tqdm

from .model import AIImageDetector, iter_images

app = typer.Typer(help="Simple AI-generated image detector powered by UnivFD/CLIP.")
console = Console()


@app.command()
def detect(
    path: Path = typer.Argument(..., help="Image file or directory."),
    recursive: bool = typer.Option(True, "--recursive/--no-recursive", help="Scan folders recursively."),
    threshold: float = typer.Option(0.5, help="AI probability threshold."),
    device: Optional[str] = typer.Option(None, help="cuda, cpu, or auto when omitted."),
    weight_path: Optional[Path] = typer.Option(None, help="Optional local fc_weights.pth path."),
    json_output: bool = typer.Option(False, "--json", help="Print JSON lines instead of a table."),
    csv_output: Optional[Path] = typer.Option(None, "--csv", help="Save CSV report."),
) -> None:
    """Detect whether an image, or images in a folder, are AI-generated."""
    paths = iter_images(path, recursive=recursive)
    if not paths:
        raise typer.BadParameter(f"No supported images found at {path}")

    detector = AIImageDetector(device=device, threshold=threshold, weight_path=weight_path)
    results = []
    for image_path in tqdm(paths, disable=json_output or len(paths) == 1):
        try:
            results.append(detector.predict_path(image_path))
        except Exception as exc:  # noqa: BLE001
            console.print(f"[red]Failed:[/red] {image_path} ({exc})")

    if csv_output:
        with csv_output.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=["path", "label", "probability_ai", "probability_real", "confidence", "raw_score"],
            )
            writer.writeheader()
            writer.writerows([r.as_dict() for r in results])
        console.print(f"Saved CSV report to {csv_output}")

    if json_output:
        for result in results:
            print(json.dumps(result.as_dict(), ensure_ascii=False))
        return

    table = Table(title="AI Image Detection Results")
    table.add_column("Image")
    table.add_column("Label")
    table.add_column("AI Prob", justify="right")
    table.add_column("Real Prob", justify="right")
    table.add_column("Confidence", justify="right")
    for result in results:
        row_style = "red" if result.label == "ai" else "green"
        table.add_row(
            str(result.path),
            result.label.upper(),
            f"{result.probability_ai:.3f}",
            f"{result.probability_real:.3f}",
            f"{result.confidence:.3f}",
            style=row_style,
        )
    console.print(table)
    console.print("[yellow]Note:[/yellow] AI image detection is probabilistic; do not use it as sole proof.")


@app.command()
def serve(
    threshold: float = typer.Option(0.5, help="AI probability threshold."),
    device: Optional[str] = typer.Option(None, help="cuda, cpu, or auto when omitted."),
    weight_path: Optional[Path] = typer.Option(None, help="Optional local fc_weights.pth path."),
) -> None:
    """Launch a local Gradio web UI."""
    try:
        import gradio as gr
    except ImportError as exc:
        raise typer.BadParameter("Install web extras first: pip install 'ai-image-detector[web]'") from exc

    detector = AIImageDetector(device=device, threshold=threshold, weight_path=weight_path)

    def predict(image):
        if image is None:
            return {"error": "Please upload an image."}
        result = detector.predict_image(image)
        return result.as_dict()

    demo = gr.Interface(
        fn=predict,
        inputs=gr.Image(type="pil", label="Upload image"),
        outputs=gr.JSON(label="Detection result"),
        title="AI Image Detector",
        description="UnivFD/CLIP-based AI-generated image detector. Results are probabilistic.",
    )
    demo.launch()


if __name__ == "__main__":
    app()
