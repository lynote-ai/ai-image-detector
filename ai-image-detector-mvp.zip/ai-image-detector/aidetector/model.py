from __future__ import annotations

from pathlib import Path
from typing import Iterable

import torch
from huggingface_hub import hf_hub_download
from PIL import Image, ImageOps

from .config import DEFAULT_MODEL_NAME, DEFAULT_PRETRAINED, FC_WEIGHT_PATH_IN_REPO, IMAGE_EXTENSIONS, MODEL_REPO_ID
from .types import DetectionResult


class AIImageDetector:
    """UnivFD-style detector: CLIP image encoder + linear fake/real head.

    The original UnivFD project evaluates a CLIP ViT-L/14 backbone with a small
    trained linear layer. This implementation wraps that idea into a simple API.
    """

    def __init__(
        self,
        device: str | None = None,
        threshold: float = 0.5,
        model_name: str = DEFAULT_MODEL_NAME,
        pretrained: str = DEFAULT_PRETRAINED,
        weight_path: str | Path | None = None,
        repo_id: str = MODEL_REPO_ID,
    ) -> None:
        self.device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
        self.threshold = threshold
        self.model_name = model_name
        self.pretrained = pretrained
        self.repo_id = repo_id

        try:
            import open_clip
        except ImportError as exc:
            raise RuntimeError("Missing dependency: install open_clip_torch.") from exc

        self.clip_model, _, self.preprocess = open_clip.create_model_and_transforms(
            model_name, pretrained=pretrained, device=self.device
        )
        self.clip_model.eval()

        # CLIP ViT-L/14 image embedding dimension is 768; we infer when possible.
        output_dim = getattr(getattr(self.clip_model, "visual", None), "output_dim", 768)
        self.head = torch.nn.Linear(int(output_dim), 1).to(self.device)
        self._load_head(weight_path)
        self.head.eval()

    def _load_head(self, weight_path: str | Path | None) -> None:
        if weight_path is None:
            weight_path = hf_hub_download(
                repo_id=self.repo_id,
                filename=FC_WEIGHT_PATH_IN_REPO,
            )
        state = torch.load(str(weight_path), map_location="cpu")
        if isinstance(state, dict) and "state_dict" in state:
            state = state["state_dict"]

        # Support several common checkpoint key formats.
        if isinstance(state, dict):
            cleaned = {}
            for key, value in state.items():
                key = key.replace("module.", "")
                key = key.replace("fc.", "")
                key = key.replace("head.", "")
                if key in {"weight", "bias"}:
                    cleaned[key] = value
            if cleaned:
                self.head.load_state_dict(cleaned, strict=False)
                return
            try:
                self.head.load_state_dict(state, strict=False)
                return
            except Exception as exc:  # noqa: BLE001
                raise RuntimeError(f"Could not load UnivFD head weights from {weight_path}: {exc}") from exc
        raise RuntimeError(f"Unsupported checkpoint format: {type(state)!r}")

    @torch.inference_mode()
    def predict_image(self, image: Image.Image, path: Path | None = None) -> DetectionResult:
        image = ImageOps.exif_transpose(image).convert("RGB")
        tensor = self.preprocess(image).unsqueeze(0).to(self.device)
        features = self.clip_model.encode_image(tensor)
        features = features / features.norm(dim=-1, keepdim=True)
        logit = self.head(features).squeeze().float()
        probability_ai = torch.sigmoid(logit).item()
        label = "ai" if probability_ai >= self.threshold else "real"
        probability_real = 1.0 - probability_ai
        confidence = probability_ai if label == "ai" else probability_real
        return DetectionResult(
            path=path,
            label=label,
            probability_ai=probability_ai,
            probability_real=probability_real,
            confidence=confidence,
            raw_score=logit.item(),
        )

    def predict_path(self, path: str | Path) -> DetectionResult:
        path = Path(path)
        with Image.open(path) as image:
            return self.predict_image(image, path=path)

    def predict_many(self, paths: Iterable[str | Path]) -> list[DetectionResult]:
        return [self.predict_path(path) for path in paths]


def iter_images(path: str | Path, recursive: bool = True) -> list[Path]:
    root = Path(path)
    if root.is_file():
        return [root] if root.suffix.lower() in IMAGE_EXTENSIONS else []
    globber = root.rglob if recursive else root.glob
    return sorted(p for p in globber("*") if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS)
