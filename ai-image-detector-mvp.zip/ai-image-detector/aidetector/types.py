from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class DetectionResult:
    path: Path | None
    label: str
    probability_ai: float
    probability_real: float
    confidence: float
    raw_score: float

    def as_dict(self) -> dict:
        return {
            "path": str(self.path) if self.path else None,
            "label": self.label,
            "probability_ai": round(self.probability_ai, 6),
            "probability_real": round(self.probability_real, 6),
            "confidence": round(self.confidence, 6),
            "raw_score": round(self.raw_score, 6),
        }
