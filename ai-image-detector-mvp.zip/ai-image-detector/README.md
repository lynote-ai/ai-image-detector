# AI Image Detector

A small, friendly open-source AI-generated image detector, inspired by the "yt-dlp / rembg" style: install it, run one command, get a result.

Core idea: **UnivFD / UniversalFakeDetect** — CLIP ViT-L/14 image features plus a tiny linear classifier head.

> Warning: AI image detection is probabilistic. Do not use this tool as sole proof that an image is real or fake.

## Install

```bash
pip install -e .
```

For the web UI:

```bash
pip install -e '.[web]'
```

## Usage

Detect one image:

```bash
aidetect detect image.jpg
```

Detect a folder recursively:

```bash
aidetect detect ./images --csv report.csv
```

JSON lines output:

```bash
aidetect detect ./images --json
```

Launch local web UI:

```bash
aidetect serve
```

## Model weights

On first run, the package downloads the small UnivFD linear head from Hugging Face:

- `siddharthksah/deepsafe-weights/universalfakedetect/fc_weights.pth`

The CLIP ViT-L/14 backbone is loaded via `open_clip_torch` using OpenAI weights.

You can also pass a local head checkpoint:

```bash
aidetect detect image.jpg --weight-path ./fc_weights.pth
```

## Output

Each result contains:

```json
{
  "label": "ai",
  "probability_ai": 0.873,
  "probability_real": 0.127,
  "confidence": 0.873,
  "raw_score": 1.926
}
```

## Roadmap

- [x] CLI detection
- [x] Folder batch detection
- [x] CSV and JSON output
- [x] Local Gradio UI
- [ ] FastAPI server
- [ ] Docker image
- [ ] Evaluation script on GenImage subset
- [ ] Optional ensemble mode

## Attribution

This project wraps the UniversalFakeDetect / UnivFD approach for easier use.
Please cite the original work if this helps your project:

```bibtex
@inproceedings{ojha2023fakedetect,
  title={Towards Universal Fake Image Detectors that Generalize Across Generative Models},
  author={Ojha, Utkarsh and Li, Yuheng and Lee, Yong Jae},
  booktitle={CVPR},
  year={2023}
}
```

Original project: https://github.com/WisconsinAIVision/UniversalFakeDetect
